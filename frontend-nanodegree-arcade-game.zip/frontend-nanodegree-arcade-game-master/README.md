frontend-nanodegree-arcade-game
===============================

Games have a lot of objects and those objects do a lot of different things; but sometimes they do some very similar things as well. This created a great opportunity to practice object-oriented programming, an important programming paradigm that influences the application architecture and provides performance optimization.

You have to get to the other side of the road without being attacked by the moving bugs across the road. Upon successfully crossing the road you shall win the game.

Obtaining/ downloading Game files and starting the Game:

    Download the Game file from GitHub
    Locate and open index.html file on a browser

How to Play: As explained above inorder to play the game the player/ You have to get to the other side of the road without being attacked by the moving bugs. To play use your keyboard arrow keys Up to move forward Down to move back Left to move left Right to move right

End and starting of the game The Game end when you cross the road successfully, and a message box appears telling you that you have won and upon clicking ok or enter key a new game starts.

The other way the game ends is when you are attacked by one of the bugs. A message box appears notifying you that you have lost the game and upon closing the message box a new game begins.

Hint: You will get attacked by any of the bugs upon touching/ colliding with them in any side.

Good Luck playing!